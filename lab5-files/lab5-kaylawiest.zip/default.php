<?php

require_once('header.php');

?>

<h1>Welcome to the Ski Race Online Tracker</h1>

</body>
</html>
