<html>
<body>

<?php

require_once('header.php');

?>

<form method="post" action="search_results.php">
<div>
	<label>Keywords</label>
	<input name="keywords" />
</div>
<input type="Submit" value="Search" />

</body>
</html>
