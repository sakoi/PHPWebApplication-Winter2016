<?php

//connect to db
$conn = new PDO('mysql:host=sql.computerstudi.es;dbname=gc200321034', 'gc200321034', 'KqxeZ*gk');
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>